import aws_sdk from 'aws-sdk';
const sns = new aws_sdk.SNS();

export const handler = async (event) => {
    const message = event.message;

    const params = {
        Message: message,
        Subject: "Confirmation of Application",
        TopicArn: "arn:aws:sns:us-east-1:991546718917:TestTopic"
    }
    try {
        const data = await sns.publish(params).promise();
        console.log(`Message sent successfully!`);
    }
    catch(error) {
        return {
            status: 500,
            error: error.message
        }
    }
}